pria(rita,abdul).
pria(rita,rudi).
priaa(husin,rudi).
perempuan(rudi,siti).
perempuan(rudi,tuti).
pria(siti,basir).
pria(siti,amir).