// public adalah keyword visibility
// class adalah ya kelas
// OtongSurotong adalah identifier, nama ini harus sama dengan nama filenya, misalnya ini nama file nya adalah OtongSurotong.java JADI identifier nya adalah OtongSurotong
public class OtongSurotong{

  // public adalah visibiliti, ada public ada private (tidak dibuka untuk umum)
  // main adalah default java, pokonya java harus ada main
  public static void main(String[] args) {
    System.out.println("Otong Otongan");    // ini adalah isi program nya si OtongSurotong, cuma nampilin di console aja
  }

}
