package com.wildenali;

public class Main {

    public static void main(String[] args) {
        // ini adalah komentar
        /*
        Komen multiline
        iya kan
         */

        System.out.println("Hello dan run");

        // Variable
        int x = 10;     // assignment
        System.out.println("ini adalah variable " + x);

        x = 20;
        System.out.println("ini adalah variable " + x);

        // Deklarasi
        int b;          // Declaration
        b = 89;
        System.out.println("ini adalah deklarasi " + b);

    }

}
