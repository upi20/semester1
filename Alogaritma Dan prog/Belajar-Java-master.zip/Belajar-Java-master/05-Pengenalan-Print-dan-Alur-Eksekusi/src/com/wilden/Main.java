package com.wilden;

public class Main {

    public static void main(String[] args) {
        System.out.println("Hellow 05 Pengenalan Alur Eksekusi");
        System.out.println("Hellow ini baris ke dua");
        System.out.print("ini Baris ketiga");
        System.out.print("ini Baris keempat \n");
        System.out.printf("wiro sableng %d", 212);
    }

}
