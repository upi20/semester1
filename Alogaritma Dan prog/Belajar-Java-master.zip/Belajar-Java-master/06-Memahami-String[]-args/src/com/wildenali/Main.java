package com.wildenali;

public class Main {

    public static void main(String[] args) {        // String[] adalah input yang bisa kita masukan di dalam program java
                                                    // String[] adalah sebuah data yang memiliki indeks array
        System.out.println(args[0]);
//        System.out.println(args[1]);
        System.out.println("Helow kawan-kawan " + args[0]);
    }

}
