package com.wildenali;

public class Main {

    public static void main(String[] args) {
	    // Operator Assignment

        // Assisgnment Operator Jumlah
        int a = 1;
        a += 10;    // a = a + 10
        System.out.println("nilai a = " + a);

        // Assisgnment Operator Kurang
        int b = 100;
        b -= 25;    // b = b - 25
        System.out.println("nilai b = " + b);

        // Assisgnment Operator Kali
        int c = 100;
        c *= 20;    // c = c x 20
        System.out.println("nilai c = " + c);

        // Assisgnment Operator Bagi
        int d = 100;
        d /= 20;    // d = d / 20
        System.out.println("nilai d = " + d);

        // Assisgnment Operator Modulus
        int e = 10;
        e %= 7;    // e = e % 7
        System.out.println("sisa bagi nya adalah = " + e);
    }
}
