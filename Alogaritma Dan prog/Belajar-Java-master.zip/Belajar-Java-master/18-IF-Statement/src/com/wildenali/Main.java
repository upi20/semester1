package com.wildenali;

public class Main {

    public static void main(String[] args) {

        int a = 5;
        System.out.println("Nilai = " + a);

        if (a == 19) {
            System.out.println("Ini adalah jalur TRUE");
        } else {
            System.out.println("Ini adalah jalur FALSE");
        }

        System.out.println("Selesaii......");

    }
}
