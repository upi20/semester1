package programku;

public class OtongSurotong{

  public static void main(String[] args) {
    System.out.println("Otong Otongan");    // ini adalah isi program nya si OtongSurotong, cuma nampilin di console aja
  }

}
