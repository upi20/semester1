package com.wilden;

public class Main{

  public static void main(String[] args) {
    System.out.println("Hai World Otong");
  }

}
