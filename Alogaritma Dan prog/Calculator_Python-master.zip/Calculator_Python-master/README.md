Calculator_Python
=================

A calculator based on python.
基于Pyqt
Python写的计算器

requirement:
pyqt4
python 2.7.5
