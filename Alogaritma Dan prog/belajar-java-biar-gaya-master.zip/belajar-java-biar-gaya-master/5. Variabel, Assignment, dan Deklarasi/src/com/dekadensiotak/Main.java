package com.dekadensiotak;

public class Main {

    public static void main(String[] args){
        // VARIABLE
        // nilainya bisa berubah
        int x = 10; // ini teh assignment

        // int adalah tipe data
        // x adalah nama variable / identifier
            // namanya teh gaboleh yang udah ada di java
        // = adalah operator assignment
        // 10 adalah nilai variable
        // nilainya ditaruh di memori komputer

        System.out.println("nilai x = " + x);

        x = 20;
        System.out.println("nilai x baru = " + x);

        // DEKLARASI
        int b; // nah gini nih, cuman ngasih tau doang kalau b teh adalah integer

        b = 7;
        System.out.println("nilai b = " + b);
    }
}
