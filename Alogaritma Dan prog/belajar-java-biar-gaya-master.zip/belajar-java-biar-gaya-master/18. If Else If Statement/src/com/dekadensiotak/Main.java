package com.dekadensiotak;

public class Main {

    public static void main(String[] args) {

        int a = 9;
        System.out.println("ini adalah awal program");
        // if else if statement

        if (a == 5){
            System.out.println("ini adalah aksi satu");
        } else if (a == 10) {
            System.out.println("ini adalah aksi dua");
        } else {
            System.out.println("ini adalah aksi default");
        }


        // akhir dari if else if statement
        System.out.println("ini adalah akhir program");
    }
}
