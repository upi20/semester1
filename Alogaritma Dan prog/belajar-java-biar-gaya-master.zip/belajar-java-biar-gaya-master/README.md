# belajar-java-biar-gaya 
(ngikutin kelas terbuka kang pukis feat. programming with mosh)

# KELAS TERBUKA
* <b>Kelas Terbuka on YouTube:</b> https://www.youtube.com/kelasterbuka
* <b>Playlist Belajar Java Dasar:</b> https://www.youtube.com/watch?v=uHyfQV0kbgo&list=PLZS-MHyEIRo51w0Hmqi0C8h2KWNzDfo6F

# PROGRAMMING WITH MOSH
* <b>Programming With Mosh on Youtube:</b> https://www.youtube.com/programmingwithmosh
* <b>Java Tutorial for Beginners [2019]:</b> https://youtu.be/eIrMbAQSU34
* <b>Java Cheat Sheet [PDF]:</b> https://programmingwithmosh.com/wp-content/uploads/2019/07/Java-Cheat-Sheet.pdf

# FURTHER READING
* <b>The Java™ Tutorials:</b> https://docs.oracle.com/javase/tutorial/java/index.html
* <b>Formatter:</b> https://docs.oracle.com/javase/7/docs/api/java/util/Formatter.html
* <b>GeeksforGeeks | Java:</b> https://www.geeksforgeeks.org/java
* <b>Java Heap Space vs Stack – Memory Allocation:</b> https://www.journaldev.com/4098/java-heap-space-vs-stack-memory
* <b>JDK 12 Documentation:</b> https://docs.oracle.com/en/java/javase/12/
* <b>Regular Expression:</b> https://www.vogella.com/tutorials/JavaRegularExpressions/article.html