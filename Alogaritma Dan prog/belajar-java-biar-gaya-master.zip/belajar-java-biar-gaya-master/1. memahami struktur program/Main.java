public class Main{
    
    // ini teh disebut juga method
    public static void main(String[] args){
        System.out.println("hello mantan");
    }
}

// {} --> Body-nya
// Class --> harus ada, keywords bersama Public
// Public --> Visibility, keywords bersama Class
// Main--> identifier dari class-nya. Penamaannya harus sama dengan nama file-nya. Huruf depannya harus besar. Kalau namanya panjang begimana? Pake camel case. Onta style
