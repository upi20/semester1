//kagak pake visibility bisa loh
class UjangSutisna {
// class adalah container untuk fungsi-fungsi yang berhubungan
    
// harus ada isinya nih. biar bisa di-run
// karena Java Virtual Machine bakal nyari pintu programmnya dari mana? nah pintu itu teh namanya main()
// jadi, setiap class di java harus ada main function

//nah kayak gini isinya
    
    public static void main(String[] args) {
        // nah ini body lagi, karena di dalem kurung kurawal juga. body dalam body laaaah

        // ini teh function
        // function adalah suatu blok kode untuk melakukan suatu perintah
        // dalam java, minimal harus ada satu fungsi

        // void adalah salah satu return type
        // main() -> the door tea gening -- adalah nama fungsinya
        
        // ini juga adalah method
        // method adalah fungsi yang merupakan bagian dari sebuah class
    
        System.out.print("anjing lu bangsat");

        // System teh library java yang dipakai untuk ngakses console apapun nanti yang dipakai. CMD lah contohnya
        // out teh buat ngirim data ke console tea
        // print() --> itu teh perintahnya. untuk nyetak sesuatu itu teh. echo lah kalau di php mah
        // jangan lupa titik koma bos
    }

// public di atas itu juga visibility. Pastinya ada private juga. Sama lah kayak php

// main() --> udah default nih. harus ada di program java. pintunya tea geningan.


}
