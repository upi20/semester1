package programku;
// nih anjing jadi ada folder programku juga di bin
// di run-nya harus ditulis packagenya juga package.bin

//kagak pake visibility bisa loh
class UjangSutisna {

// harus ada isinya nih. biar bisa di-run
// karena Java Virtual Machine bakal nyari pintu programmnya dari mana? nah pintu itu teh namanya main()

//nah kayak gini isinya

    public static void main(String[] args){
        // nah ini body lagi, karena di dalem kurung kurawal juga. body dalam body laaaah
        System.out.print("anjing lu bangsat");

        // System teh library java yang dipakai untuk ngakses console apapun nanti yang dipakai. CMD lah contohnya
        // out teh buat ngirim data ke console tea
        // print() --> itu teh perintahnya. untuk nyetak sesuatu itu teh. echo lah kalau di php mah
        // jangan lupa titik koma bos
    }

// public di atas itu juga visibility. Pastinya ada private juga. Sama lah kayak php

// main() --> udah default nih. harus ada di program java. pintunya tea geningan.


}