package com.dekadensiotak;

//java teh eksekusinya baris per baris. dari atas ke bawah

public class Main {
    //kalau di bawah ini teh method. ada kurung kurawalnya gitu. body dalem body tea geningan
    public static void main(String[] args){
        //di bawah ini teh statement, diakhiri titik koma
        System.out.println("hello anjing");
        System.out.println("hello juga bangsat");

        System.out.print("tah kalau ga ada ln nya mah ga nambah baris");
        System.out.print("tuh kan anying");

        System.out.print("tah kalau gini bisa juga baris baru nih \n");
        System.out.print("tuh kan bangsaaaat \n");

        System.out.printf("saya suka blink-%d",182);
    }
}
