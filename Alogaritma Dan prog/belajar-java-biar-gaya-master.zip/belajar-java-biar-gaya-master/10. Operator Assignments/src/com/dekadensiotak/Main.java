package com.dekadensiotak;

public class Main {

    public static void main(String[] args) {

        int a = 1;
        a = a + 5; // hasilnya 6
        a = a + 10; // hasilnya 16
        System.out.println("nilai a = " + a);

        // Operator Assignment

        // penjumlahan
        int b = 1;
        b += 5; // hasilnya 6
        b += 10; // hasilnya 16
        System.out.println("nilai b = " + b);

        // pengurangan
        int c = 20;
        c -= 5;
        System.out.println("nilai c = " + c);

        // perkalian
        int d = 20;
        d *= 5;
        System.out.println("nilai d = " + d);

        // pembagian
        int e = 20;
        e /= 5;
        System.out.println("nilai e = " + e);

        // modulus
        int f = 21;
        f %= 5;
        System.out.println("nilai f = " + f);

    }
}
