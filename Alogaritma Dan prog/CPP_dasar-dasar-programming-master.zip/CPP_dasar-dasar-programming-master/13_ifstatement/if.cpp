#include <iostream>

using namespace std;

int main()
{
	int a;

	cout << "masukan angka = ";
	cin >> a;

	// if statement
	// kondisi dalam bentuk boolean
	if (a == 5)
	{
		cout << "halooo" << endl;
	}

	cout << "selesai" << endl;
	cin.get();
	return 0;
}
