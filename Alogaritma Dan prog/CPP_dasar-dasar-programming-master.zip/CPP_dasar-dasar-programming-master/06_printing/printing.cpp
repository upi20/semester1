#include <iostream> 

int main(){
	std::cout << "halo sodara-sodara sekalian\n";
	std::cout << "ini adalah baris baru.";
	std::cout << "ini bukan baris baru.";
	std::cout << " ini akhir kalimat." << std::endl;
	std::cin.get();
	return 0;
}