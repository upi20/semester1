namespace otong {
	int b = 10;

	void fungsi(){
		std::cout << "ini adalah fungsi si otong" << std::endl;
	}

	void cout(int a){
		std::cout << a << std::endl;
	}
}