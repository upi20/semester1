#include <iostream>

//comment
/* multi
line
comment
*/

int main()
{
	int a;
	std::cout << "halo kalian" << std::endl;
	std::cin >> a;
	std::cout << a << std::endl;
	return 0;
}