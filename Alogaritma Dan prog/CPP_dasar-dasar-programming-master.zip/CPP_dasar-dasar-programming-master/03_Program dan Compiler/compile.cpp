#include <iostream>

int tambah(int a, int b);

int main()
{
	std::cout << tambah(2,3) << std::endl;
	return 0;
}