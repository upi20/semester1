int tambah (int a, int b){
	return (a + b);
}