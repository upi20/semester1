#include <iostream>

int main(){

	int a = 5;

	std::cout << a << std::endl;
	std::cin.get();
	return 0;
}