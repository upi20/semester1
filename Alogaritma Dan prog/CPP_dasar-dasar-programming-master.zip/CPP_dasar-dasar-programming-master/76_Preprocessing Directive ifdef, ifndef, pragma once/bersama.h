//#ifndef _BERSAMA
//#define _BERSAMA
#pragma once

struct Mahasiswa {
	int NIM;
};

//#endif