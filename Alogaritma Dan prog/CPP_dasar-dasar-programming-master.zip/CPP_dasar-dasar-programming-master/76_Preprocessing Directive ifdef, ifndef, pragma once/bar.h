
// #ifdef FOO
// #else
// #define FOO "ini adalah foo dalam bar.h"
// #endif

#include "bersama.h"
