#include <iostream>

// macro
#define PI 3.14159265359

using namespace std;

double pi = 3.14159265359; 
int main()
{
	cout <<" nilai pi double = " << pi << endl;
	cout << &pi << endl;
	cout << "nilai PI=" << PI << endl;
	cin.get();
	return 0;
}