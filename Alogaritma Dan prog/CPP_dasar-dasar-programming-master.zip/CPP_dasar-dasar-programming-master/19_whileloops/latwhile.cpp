#include <iostream>

using namespace std;

int main()
{

	int a = 5;
	
	while(a <= 10){
		cout << "hore ";
		cout << a << endl;
		a += 1;
	}

	cout << "selesai" << endl;

	cin.get();
	return 0;
}
