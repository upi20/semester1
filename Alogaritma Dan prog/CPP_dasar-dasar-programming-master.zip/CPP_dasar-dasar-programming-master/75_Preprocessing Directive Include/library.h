#include <string>

#define PI 3.14159265359
#define KUADRAT(X) (X*X)
#define MAX(A,B) ((A > B) ? A:B)

std::string data = "STRING";