calculator
==========

Calculator implemented in Python