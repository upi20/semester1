# NUMBER DAN OPERASI MATEMATIKA

# c = a + b print (c)
# c = a + b print ("Penjumlahan a + b = ", c)
# print (a + b)

a = 6
b = 3

# penjumlahan
print("Penjumlahan a + b = ", a + b)

# pengurangan
print("Pengurangan a - b = ", a - b)

# perkalian
print("Perkalian a * b = ", a * b)

# pembagian
print("Pembagian a / b = ", a / b)

# pembagian pembulatan
print("Pembagian Pembulatan a // b = ", a // b)

# pemangkatan
print("Pemangkatan a ** b = ", a ** b)

# modulus
print("Modulus a % b = ", a % b)