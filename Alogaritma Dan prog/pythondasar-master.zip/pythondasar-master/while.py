angka = 0

while angka < 5:
    print("Nilai :", angka)
    angka = angka + 1

print("diluar while")

start = True
angka = 0

while start:
    print("di dalam while")
    if angka is 100:
        start = False
        print("oke angka ditemukan")
    angka += 1