# list
ganjil = [1, 3, 5, 7, 9]

# tuple (tidak bisa di edit, tambah, hapus hanya bisa count, dan index)
genap = (2, 4, 6, 8)

print(type(ganjil))
print(type(genap))

print(dir(ganjil))
print(dir(genap))