# scope variavel local

nama = "Mozza"
makan = "Royal"

def rubahnama(namabaru):
    global nama
    nama = namabaru # global
    namakucing = namabaru # local
    print("saya rubah nama kucing menjadi", nama)

def kasihmakan(makanan, namabaru):
    global nama, makan
    nama = namabaru
    makan = makanan

rubahnama("Mozzie")

kasihmakan("universal", "Alex")

print("nama kucing saya", nama, "dan makan", makan)