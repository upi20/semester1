from collections import deque

antrian = deque([1, 2, 3, 4, 5])
print(antrian)

# menambahkan data
antrian.append(6)
print(antrian)

antrian.append(7)
print(antrian)

# mengurangi data
antrian.popleft()
print(antrian)