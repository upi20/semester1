# nilai = 80

# if nilai == 75:
#     print("Nilai anda:", nilai)

# if nilai == 80:
#     print("Nilai anda:", nilai)

# nilai1 = 75
# nilai2 = 80

# if nilai1 == 75:
#     print("Nilai Anda:", nilai1)
#     if nilai2 == 80:
#         print("Nilai anda:", nilai2)

# nilai = 75
# if nilai is 75:
#     print("Nilai Anda:", nilai)

# nilai = 70
# if nilai is not 75:
#     print("Nilai Anda bukan: 75")

# nilai = 45
# if 80 <= nilai <= 100:
#     print("Nilai anda adalah A")
# elif 70 <= nilai < 80:
#     print("Nilai anda adalah B")
# elif 60 <= nilai < 70:
#     print("Nilai anda adalah C")
# elif 50 <= nilai < 60:
#     print("Nilai anda adalah D")
# else:
#     print("Maaf anda tidak lulus, RABI AE")

# operator logika untuk list dan string
gorengan = ["bakwan", "cireng", "pisang goreng", "bala-bala", "gehu", "combro", "pukis", "risoles"]
beli = "cireng"

# if beli in gorengan:
#     print("Mamang bilang 'ya saya jual",beli,"'")
# if not beli in gorengan:
#     print("'saya gak jual",beli,"'")

karakter = "z"
if karakter in beli:
    print("Ada", karakter,"di",beli)
else:
    print("tidak ada", karakter)