text = "Data String"

text2 = "Jalan-jalan dihari jum'at" #"Jalan-jalan dihari jum\"at"

text3 = "A: 'Kemaren kemana bro?' \n B: 'Jalan-jalan bro'"

text4 = """
A: Kenapa bro?"
B: Gapapa bro"
A: Yakin?"
B: Iya yakin"
"""

text5 = r"C:\nyoto"# raw string

print(text5)
print(10*"wk")
print("Izza" "Fathony")
print(text+text2)