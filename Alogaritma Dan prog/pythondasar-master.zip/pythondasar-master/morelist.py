barang = ["kunci", "ember", "jaket", "ban", "mobil"]
print(barang)

# beberapa method untuk memanipulasi list
# method untuk menambah data kedalam list
barang.append("sepeda")
print(barang)

data = "test"
for i in data:
    print(i)
print(data[1])

barang.extend("dompet")
print(barang)

barang.insert(3, "mouse")
print(barang)

# method untuk menghitung anggota list
jumlah = barang.count("sepeda")
print(jumlah)

# remove data
barang.remove("mouse")
print(barang)

barang.reverse()
print(barang)

stuff = barang.copy()
stuff.append("gelas")
print(stuff)
print(barang)