# else, break, continue, pass

angka = 0

while angka < 10:

    if angka is 5:
        # print("checkpoint1")
        angka += 1
        # break
        continue
        # pass
        # print("checkpoint1")

    print("Nilai :", angka)
    angka += 1
else:
    print("sudah selesai")

print("diluar")