tumpukan = [1, 2, 3, 4, 5, 6]
print(tumpukan)

# memasukkan data baru
tumpukan.append(7)
print(tumpukan)

tumpukan.pop()
print(tumpukan)