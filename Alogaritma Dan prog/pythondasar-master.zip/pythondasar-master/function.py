# # mendefinisikan fungsi
# def fungsi():
#     print("ini adalah fungsi")

# # memanggil fungsi
# fungsi()


# membuat fungsi sederhana
def suaraayam():
    print("kukuruyuk")

def hargaayam():
    suaraayam()
    print("harga ayam adalah Rp 20.000")

hargaayam()

# membuat fungsi dengan argument
def hargatotalayam(kg):
    suaraayam()
    harga = 20000
    hartot = kg*harga
    print("harga", kg, "kg ayam adalah", hartot)

hargatotalayam(5)