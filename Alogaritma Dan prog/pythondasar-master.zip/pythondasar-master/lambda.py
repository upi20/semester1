# membuar anonymous function dengan lambda
kali = lambda x,y: x*y
hasil = kali(3,4)

print(hasil)