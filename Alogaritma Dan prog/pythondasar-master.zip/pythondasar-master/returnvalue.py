# fungsi dengan return value
def kuadrat(argumen):
    total = argumen**2
    return total

a = kuadrat(5)
print(a)
#   print(kuadrat(5))

# fungsi dengan return value dan multiple argument
def tambah(argumen1, argumen2):
    total = argumen1 + argumen2
    print(argumen1, "+", argumen2, "=", total)
    return total

def kali(argumen1, argumen2):
    total = argumen1 * argumen2
    print(argumen1, "x", argumen2, "=", total)
    return total

a = tambah(3,4)
b = kali(3,a)

print(a)
print(b)