cari = 11
for i in range(1,10):
    print(i)
    if i is cari:
        print("angka ditemukan", i)
        break
else:
    print("angka", cari ,"tidak ditemukan")

print("space diluar for")