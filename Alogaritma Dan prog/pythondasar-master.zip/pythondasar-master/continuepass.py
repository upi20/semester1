for i in range(1,10):
    if i is 6:
        print("Nilai i:",6)
        # break : untuk mengakhiri for
        # continue : untuk melanjutkan ke step berikutnya
        # pass : default

    print(i)
else:
    print("akhir loop")

print("luar loop")

for i in range(9,100):
    pass