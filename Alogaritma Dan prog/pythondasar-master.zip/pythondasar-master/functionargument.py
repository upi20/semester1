# fungsi dengan menggunakan argumen sederhana
def siswa(nama):
    print("Nama:",nama)

siswa("Izza")

# fungsi dengan menggunakan keyword argument
def guru(nama, pelajaran):
    print("guru", nama, "mengajar",pelajaran)

guru("Pak Noval", "Database")
guru("Database", "Pak Noval") # ini salah
guru(nama = "Bu Irez", pelajaran = "PHP")
guru(pelajaran="olahraga", nama="bebas")

# fungsi dengan menggunakan default argument
def satpam(nama, shift="siang", galak="tidak"):
    print("satpam", nama, "bekerja shift", shift, "galak?", galak)

satpam("Pak Mul")