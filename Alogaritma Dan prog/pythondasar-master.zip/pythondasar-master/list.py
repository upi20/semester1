Data = [1, 3, 5, 7, 9, 11, 13, 15]

# mengakses list
Subdata = Data[3] # 7
Subdata2 = Data[-3] # 11

# memotong list
Subdata3 = Data[2:4] # 5, 7
Subdata4 = Data[:4] # 1, 3, 5, 7

Data2 = [100, 200, 300, 400, 500, 600, 700, 800]

# menambah list
Data3 = Data + Data2 # 1, 3, 5, 7, 9, 11, 13, 15, 100, 200, 300, 400, 500, 600, 700, 800

# merubah isi list

Data[4] = 10

# mencopy list ke variable baru
a = Data[:]
a[4] = 10

# merubah isi list dengan menggunakan metode slicing
Data[3:5] = [8, 10]

# list dalam list
x = [Data, Data2]

# mengakses dalam multidemsional list
y = x[0][4]

# method untuk list
Data.append(17)

# function yang bisa digunakan untuk list
panjanglist = len(Data)

print(panjanglist)