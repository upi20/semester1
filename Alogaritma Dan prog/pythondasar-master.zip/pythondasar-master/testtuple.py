import sys

datalist = [1, 2, 3, 4, 5, "pisang", "eminem", "bmth", False, 3.14]
datatuple = (1, 2, 3, 4, 5, "pisang", "eminem", "bmth", False, 3.14)

besarlist = sys.getsizeof(datalist)
besartuple = sys.getsizeof(datatuple)

print(besarlist)
print(besartuple)