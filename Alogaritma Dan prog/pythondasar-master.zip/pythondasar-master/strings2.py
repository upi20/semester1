text = "Pisang Goreng"

a = text[0] #P
b = text[5] #G
c = text[0:5] #Pisan
d = text[-4] #R

print(a)