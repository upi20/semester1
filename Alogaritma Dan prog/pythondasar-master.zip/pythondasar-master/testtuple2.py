import timeit

datalist = timeit.timeit(stmt="[1, 2, 3, 4, 5, 6, 7, 8, 9]", number=1000000)
datatuple = timeit.timeit(stmt="(1, 2, 3, 4, 5, 6, 7, 8, 9)", number=1000000)

print(datalist)
print(datatuple)