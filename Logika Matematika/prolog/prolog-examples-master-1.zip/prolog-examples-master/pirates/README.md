---+ Pirates Tutorial

This is my worked solution to the pirates tutorial at 

http://cliopatria.swi-prolog.org/help/source/doc/home/vnc/prolog/src/ClioPatria/web/tutorial/Piracy.txt

place demo.pl and map.pl in the root pirates directory

gmap.pl is a one line fix to the tutorial supplied

pirates/cpack/pirates/components/gmap.pl


